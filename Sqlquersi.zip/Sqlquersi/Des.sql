USE [Task]
GO

/****** Object:  Table [dbo].[Designation]    Script Date: 3/11/2021 6:44:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Designation](
	[designation_id] [int] NULL,
	[designationname] [varchar](50) NOT NULL,
	[dept_id] [int] NULL
) ON [PRIMARY]
GO


