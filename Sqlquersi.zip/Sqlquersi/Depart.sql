USE [Task]
GO

/****** Object:  Table [dbo].[Department]    Script Date: 3/11/2021 6:44:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Department](
	[dept_id] [int] NULL,
	[deptname] [varchar](50) NOT NULL
) ON [PRIMARY]
GO


