USE [Task]
GO

/****** Object:  Table [dbo].[userinfo]    Script Date: 3/11/2021 6:45:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[userinfo](
	[person_id] [int] IDENTITY(1,1) NOT NULL,
	[first_name] [varchar](50) NOT NULL,
	[last_name] [varchar](50) NOT NULL,
	[deparment_id] [int] NULL,
	[designation_id] [int] NULL,
	[email] [varchar](50) NOT NULL,
	[phone_number] [varchar](50) NOT NULL,
	[upassword] [varchar](50) NOT NULL,
	[uconfirmpassword] [varchar](50) NOT NULL,
	[user_role] [char](1) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[person_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


